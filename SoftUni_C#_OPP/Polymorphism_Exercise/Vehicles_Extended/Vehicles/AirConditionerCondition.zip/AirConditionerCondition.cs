﻿namespace Vehicles
{
    public enum AirConditionerCondition
    {
        Off,
        On
    }
}