﻿using System;
using System.Collections.Generic;
using System.Text;
using Farm;

namespace _4.MultipleInheritance
{
   public  class Cat:Animal
    {

        public void Meow()
        {

            Console.WriteLine($"meowing...");
        }

    }
}
