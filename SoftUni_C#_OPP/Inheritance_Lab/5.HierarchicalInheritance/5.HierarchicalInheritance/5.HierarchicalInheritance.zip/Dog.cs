﻿using System;
using System.Collections.Generic;
using System.Text;
using Farm;

namespace _4.MultipleInheritance
{
    public class Dog:Animal
    {
        public void Bark()
        {
            Console.WriteLine("barking...");
        }
    }
}
