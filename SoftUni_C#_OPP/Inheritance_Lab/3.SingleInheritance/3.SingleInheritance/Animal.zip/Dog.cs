﻿using System;
using System.Collections.Generic;
using System.Text;
using Farm;

namespace _3.SingleInheritance
{
    class Dog:Animal
    {
        public void Bark()
        {
            Console.WriteLine("barking...");
        }
    }
}
