﻿using System;
using System.Collections.Generic;
using System.Text;

namespace NeedForSpeed
{
    public class Motorcycle:Vehicle
    {
        public Motorcycle(int hoersePower, double fuel) : base(hoersePower, fuel)
        {
        }
    }
}
