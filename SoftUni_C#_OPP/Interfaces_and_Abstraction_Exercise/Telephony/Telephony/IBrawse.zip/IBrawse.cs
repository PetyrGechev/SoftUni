﻿namespace Telephony
{
    public interface IBrawse
    {
        public string Browse(string webSite);
    }
}