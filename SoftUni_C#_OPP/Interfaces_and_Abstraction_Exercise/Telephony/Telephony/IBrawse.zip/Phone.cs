﻿namespace Telephony
{
    public abstract  class Phone
    {
        public abstract string Call(string number);

    }
}