﻿using System;
using System.Collections.Generic;
using System.Text;

namespace BorderControl_
{
    public interface IIdentifiable
    {
        public string Id { get; }
    }
    
}
