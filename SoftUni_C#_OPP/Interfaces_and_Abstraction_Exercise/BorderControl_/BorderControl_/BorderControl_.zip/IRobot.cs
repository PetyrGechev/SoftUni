﻿using System;
using System.Collections.Generic;
using System.Text;

namespace BorderControl_
{
   public interface IRobot :IIdentifiable
    {
        public string Model { get;}
    }
}
