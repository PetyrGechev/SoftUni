﻿using System;
using System.Collections.Generic;
using System.Text;

namespace BorderControl_
{
    public interface IBirthday
    {
        public string Age { get;}
    }
}
