﻿namespace WildFarm.Food
{
    public interface IFood
    {
        //int Quantity
        public int Quantity { get;  }
    }
}