﻿namespace WildFarm.Food
{
    public class Seeds:Food

    {
        public Seeds(string name, int quantity) : base(name, quantity)
        {
        }
    }
}