﻿namespace WildFarm.Food
{
     public class Meat:Food
    {
        public Meat(string name, int quantity) : base(name, quantity)
        {

        }
    }
}