﻿namespace BirthdayCelebrations
{
    public interface IPet : IBirthday
    {
        public string Name { get; }
    }
}