﻿namespace BirthdayCelebrations
{
    public interface IAge
    {
        public string Age { get; }
    }
}