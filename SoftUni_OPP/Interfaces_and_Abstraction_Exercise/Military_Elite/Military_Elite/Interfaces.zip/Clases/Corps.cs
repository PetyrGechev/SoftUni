﻿namespace Military_Elite.Clases
{
    public enum Corps
    {
        Airforces ,
        Marines
    }
}