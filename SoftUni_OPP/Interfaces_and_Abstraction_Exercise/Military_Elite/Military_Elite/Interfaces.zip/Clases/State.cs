﻿namespace Military_Elite.Interfaces
{
    public enum State
    {
        inProgress,
        Finished
    }
}