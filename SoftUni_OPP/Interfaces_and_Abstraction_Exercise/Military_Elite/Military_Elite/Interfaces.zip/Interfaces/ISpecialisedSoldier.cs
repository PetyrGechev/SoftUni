﻿using Military_Elite.Clases;

namespace Military_Elite.Interfaces
{
    public interface ISpecialisedSoldier
    {
        public Corps Corps { get; set; }
    }
}