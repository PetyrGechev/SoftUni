﻿namespace Military_Elite.Interfaces
{
    public interface ISpy : ISoldier
    {
        //holds the code number of the Spy (int).
        public int CodeNumber { get;}
    }
}