﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Food_Shortage
{
    public interface IBirthday
    {
        public string Birthday { get;}
    }
}
