﻿namespace Food_Shortage
{
    public interface IBuyer
    {
        public void BuyFood();
        public int Food { get;}

    }
}