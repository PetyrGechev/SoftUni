﻿namespace Food_Shortage
{
    public interface IAge
    {
        public string Age { get; }
    }
}