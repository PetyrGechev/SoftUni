﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Food_Shortage
{
    public interface IIdentifiable
    {
        public string Id { get; }
    }
    
}
